MEIN BUDGET – Version 1

Funktionen:
- Einnahmen und Ausgaben
- Kategorien und Notizen
- Budgetperiode standardmässig 25. bis 25.
- Automatisches Tagesbudget
- Erspartes und Sparziel
- Lokale Speicherung auf dem Gerät
- JSON-Datensicherung

INSTALLATION:
Die Dateien müssen über eine HTTPS-Webadresse bereitgestellt werden. Öffne diese Adresse auf dem iPhone in Safari und wähle Teilen > Zum Home-Bildschirm.
Ein ZIP allein lässt sich auf dem iPhone nicht wie eine native App installieren.
